<!DOCTYPE HTML> 
<html lang="pl-PL">
<head>
    <meta name="keywords"  content="medycyna estetyczna Lublin, gabinet medycyny estetycznej Lublin, lekarz medycyny estetycznej Lublin, medycyna estetyczna cennik, medycyna estetyczna Lublin cennik, medycyna estetyczna Lublin opinie, kosmetologia Lublin opinie, gabinet kosmetologii Lublin, Makijaż permanentny Lublin opinie, Makijaż Lublin, medycyna estetyczna Lublin, gabinet Lublin, mezoterapia skóry, Likwidacja celulitu opinie, mezoterapia skóry Lublin, Likwidacja celulitu Lublin, modelowanie twarzy Lublin, toksyna botulinowa  Lublin, kwas hialuronowy, Eksfoliacja Lublin, wypełnianie zmarszczek, wypełnianie zmarszczek Lublin, kwas hialuronowy Lublin, Leczenie nadpotliwości Lublin, nici hialuronowe, nici hialuronowe Lublin, nici PDO Lublin, Rękas" />
    <title>Medycyna estetyczna, kosmetologia, makiaż permanentny | Lublin</title>
    <meta name="msvalidate.01" content="BA75FFFF03E4F0B62A7CE606DE3049C5" />
    <?php include 'metadane.html' ?>
</head>
<body>
<?php $page = 'home'; include 'header.php' ?>
    <main>
        <?php include 'main.html' ?>
    </main>
<div class="article">
    <div class="cushycms"></div>
    <?php include './pics/slideshow/with-jquery.html' ?>
</div>
<?php include 'footer.php'; ?>
</body>
</html>
