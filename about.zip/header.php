    <div id="blured"></div>
    <header id="header" >
        <div class="cushycms"> Umów się na konsultacje: tel. 609 800 282 / 793 286 888 <i class="fas fa-phone"></i></div>
        <a class="<?php if ($page=='home') {echo 'active';} else {echo 'boxcnt';} ?>" href="index.php"><div>GŁÓWNA</div></a>
        <a class="<?php if ($page=='zabiegi') {echo 'active';} else {echo 'boxcnt';}?>" href="zabiegi.php#zabiegi"><div>ZABIEGI</div></a>
        <a class="<?php if ($page=='materialy') {echo 'active';} else {echo 'boxcnt';}?>" href="materialy.php#materialy"><div>MATERIAŁY</div></a>
        <a class="<?php if ($page=='cennik') {echo 'active';} else {echo 'boxcnt';}?>" href="cennik.php#cennik"><div>CENNIK</div></a>
        <a class="<?php if ($page=='about') {echo 'active';} else {echo 'boxcnt';}?>" href="about.php#about"><div>O NAS</div></a>
    </header>