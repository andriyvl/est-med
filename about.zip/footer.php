    <div class="footer cushycms">
    <div>
        <p>Medycyna estetyczna</p>
        <p>Anna Rękas</p>
        <p>Tel. 609 800 282</p>
        <a href="mailto:aniarks@gmail.com">Email: <strong>aniarks@gmail.com</strong></a>
        
    </div>
    <div>
        <p>Kosmetologia, makiaż permanentny</p>
        <p>Urszula Ejtel-Ostaszewska</p>
        <p>Tel. 793 286 888</p>
    </div>
    <div>
        <p>Godziny pracy:</p>
        <p>pn - pt: 9:00 - 20:00</p> <p>sobota, niedziela: nieczynne</p>
    </div>
    <div>
    <p>Numer konta:</p>  <p>20 1020 3150 0000 3302 0097 5011</p>
    <p>NIP : 712 32-49-019</p>
    </div>
    <a id="copyright" href="https://www.linkedin.com/in/andriy-viychuk-b29474b4">Created by Andriy Viychuk | 2018</a>
</div>
<a id="top-arrow-btn" href="<?php $page . '#header'?>"><i class="fas fa-arrow-circle-up fa-3x"></i></a>
